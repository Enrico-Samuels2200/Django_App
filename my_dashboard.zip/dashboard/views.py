from django.shortcuts import render

# Creates a function that we called will render index.html in templates folder.
def padlet_data(request):
   return render(request, 'index.html', {})