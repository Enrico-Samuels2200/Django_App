from django.shortcuts import render

# Create your views here.
def padlet_data(request):
   return render(request, 'index.html', {})