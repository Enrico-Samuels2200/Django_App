from django.urls import path
from . import views

urlpatterns = [
    path('', views.padlet_data, name='padlet_info'),
]
