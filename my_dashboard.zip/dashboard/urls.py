from django.urls import path
from . import views

# Sets the main path to "http://localhost:8000/"
urlpatterns = [
    path('', views.padlet_data, name='padlet_info'),
]
