1. To use the app open two command line windows.
2. On wone of the cli windows navigate into the my_dashboard directory where the manage.py file exist.
3. Enter the command "python manage.py runserver" to start the server.
4. On the other cli navigate into the directory pivot-mongo.
5. Enter the command "npm install && npm run serve" to install the node modules and start the server.